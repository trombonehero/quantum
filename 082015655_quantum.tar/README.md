General Purpose Quantum Paralellization Library
by Unidef

Licensed by the BSD License

