#include "quantum.h"

OPERATIONS arrange();
OPERATIONS delete();
OPERATIONS move();
OPERATIONS rearrange();
OPERATIONS query();



SQL database();



DOC license();
DOC help();
