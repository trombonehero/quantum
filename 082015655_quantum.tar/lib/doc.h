#include "quantum.h"

// tests

TEST temp;

// id system

double long  id;
