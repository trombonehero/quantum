// system libraries

#include <stdio.h>
#include <stdlib.h>

// built in libraries

#include "types.h"
#include "doc.h"


// system variables

#define NEURAL_ARRAY 1000000
#define NEURAL_DIMENSION 20
#define NEURAL_DIRECTION "up"


