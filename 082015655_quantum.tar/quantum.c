#include "lib/quantum.h"

// additional code


int main(){
  DOC INIT;
  return 0;
};  
