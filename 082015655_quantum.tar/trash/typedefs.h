#include "types.h"


typedef struct _neural_node NODE;
typedef _neural OPERATIONS;
typedef _neural SQL;
typedef _neural TEST;
typedef _neural DOC;
typedef double long ID;
